/* Ryan Landing Pages: first-party CRM intake + consent-safe analytics contract. */
(function () {
  'use strict';

  var config = window.RYAN_LP_CONFIG || {};
  if (!config.pageSlug || (!config.preview && !config.crmEnabled)) return;

  var allowedPages = [
    'surveying-riyadh',
    'engineering-consulting-riyadh',
    'building-permits-riyadh',
    'sukuk',
  ];
  if (allowedPages.indexOf(config.pageSlug) === -1) return;

  var sessionKey = 'ryan_lp_session_v1';
  var sessionId;
  try {
    sessionId = sessionStorage.getItem(sessionKey);
    if (!sessionId) {
      sessionId = makeUuid();
      sessionStorage.setItem(sessionKey, sessionId);
    }
  } catch (e) {
    sessionId = makeUuid();
  }

  function makeUuid() {
    if (window.crypto && typeof window.crypto.randomUUID === 'function') {
      return window.crypto.randomUUID();
    }
    var bytes = new Uint8Array(16);
    if (window.crypto && window.crypto.getRandomValues) {
      window.crypto.getRandomValues(bytes);
    } else {
      for (var i = 0; i < bytes.length; i++) bytes[i] = Math.floor(Math.random() * 256);
    }
    bytes[6] = (bytes[6] & 0x0f) | 0x40;
    bytes[8] = (bytes[8] & 0x3f) | 0x80;
    var hex = Array.prototype.map.call(bytes, function (b) { return ('0' + b.toString(16)).slice(-2); }).join('');
    return hex.slice(0, 8) + '-' + hex.slice(8, 12) + '-' + hex.slice(12, 16) + '-' + hex.slice(16, 20) + '-' + hex.slice(20);
  }

  function queryValue(name) {
    try {
      return new URLSearchParams(window.location.search).get(name) || '';
    } catch (e) {
      return '';
    }
  }

  var attribution = {
    utm_source: queryValue('utm_source'),
    utm_medium: queryValue('utm_medium'),
    utm_campaign: queryValue('utm_campaign'),
    utm_term: queryValue('utm_term'),
    utm_content: queryValue('utm_content'),
    gclid: queryValue('gclid'),
    gbraid: queryValue('gbraid'),
    wbraid: queryValue('wbraid'),
    referrer: document.referrer || '',
  };

  function eventParams(name, location, method) {
    return {
      service: config.service || 'unknown',
      page_path: window.location.pathname,
      page_slug: config.pageSlug,
      cta_location: location || 'unknown',
      lead_method: method || name,
    };
  }

  function pushAnalyticsEvent(name, location, method) {
    if (config.preview) return;
    var params = eventParams(name, location, method);
    // Deliberately exclude name, phone, email, form text, click IDs and raw query strings.
    if (config.transport === 'gtm' && window.dataLayer && typeof window.dataLayer.push === 'function') {
      window.dataLayer.push(Object.assign({ event: name }, params));
    } else if (config.transport === 'ga4' && typeof window.gtag === 'function') {
      window.gtag('event', name, params);
    }
  }

  function postJson(url, body) {
    if (config.preview || !url) return;
    var payload = JSON.stringify(body);
    if (navigator.sendBeacon && window.Blob) {
      try {
        if (navigator.sendBeacon(url, new Blob([payload], { type: 'application/json' }))) return;
      } catch (e) { /* Fall through to fetch. */ }
    }
    try {
      fetch(url, {
        method: 'POST',
        credentials: 'same-origin',
        headers: { 'Content-Type': 'application/json' },
        body: payload,
        keepalive: true,
      }).catch(function () {});
    } catch (e) { /* Tracking must never block the user's action. */ }
  }

  function sendTouchpoint(name, location) {
    if (config.preview) return;
    postJson(config.eventEndpoint, Object.assign({
      event_id: makeUuid(),
      session_id: sessionId,
      event_name: name,
      page_slug: config.pageSlug,
      cta_location: location || 'unknown',
    }, attribution));
  }

  function ctaLocation(anchor) {
    var loc = (anchor && anchor.getAttribute('data-cta-location') || '').toLowerCase();
    if (/^(header|hero|service_card|floating|sticky|contact_section|footer)$/.test(loc)) return loc;
    if (anchor.closest('.float-whatsapp, .float-call, [class*="floating"], [class*="FloatingActions"]')) return 'floating';
    if (anchor.closest('[class*="sticky"], [class*="Sticky"], [class*="conversion-bar"]')) return 'sticky';
    if (anchor.closest('#contact, .sukuk-glass-form, [class*="contact"]')) return 'contact_section';
    if (anchor.closest('.landing-services-grid, .service-card, [class*="service-card"]')) return 'service_card';
    if (anchor.closest('header, [class*="site-header"], [class*="Header"]')) return 'header';
    if (anchor.closest('#home, [class*="hero"], [id*="hero"]')) return 'hero';
    if (anchor.closest('footer, [class*="footer"]')) return 'footer';
    return 'unknown';
  }

  document.addEventListener('click', function (event) {
    var target = event.target;
    if (!(target instanceof Element)) target = target && target.parentElement;
    var anchor = target && target.closest ? target.closest('a[href]') : null;
    if (!anchor) return;
    var href = (anchor.getAttribute('href') || '').trim().toLowerCase();
    var name = '';
    if (href.indexOf('tel:') === 0) name = 'phone_click';
    else if (/^(https?:)?\/\/(wa\.me|api\.whatsapp\.com|web\.whatsapp\.com|whatsapp\.com)(\/|\?|#|$)/i.test(href)) name = 'whatsapp_click';
    if (!name) return;
    var location = ctaLocation(anchor);
    var method = 'phone_click' === name ? 'phone' : 'whatsapp';
    pushAnalyticsEvent(name, location, method);
    sendTouchpoint(name, location);
  }, true);

  function inputValue(form, selector) {
    var element = form.querySelector(selector);
    return element ? String(element.value || '').trim() : '';
  }

  function findContactFields(form) {
    var inputs = Array.prototype.slice.call(form.querySelectorAll('input:not([type="hidden"]):not([type="checkbox"]):not([type="submit"]):not([type="button"])'));
    var phone = form.querySelector('input[type="tel"], input[name*="phone" i], input[name*="mobile" i]');
    var email = form.querySelector('input[type="email"], input[name*="email" i]');
    var name = form.querySelector('input[autocomplete="name"], input[name="name"], input[name*="full" i]');
    if (!name) name = inputs.find(function (input) { return input !== phone && input !== email && (!input.type || input.type === 'text'); }) || inputs[0];
    return { name: name, phone: phone, email: email };
  }

  function insertBeforeSubmit(form, node) {
    var button = form.querySelector('button[type="submit"], input[type="submit"]');
    if (button && button.parentNode) button.parentNode.insertBefore(node, button);
    else form.appendChild(node);
  }

  function prepareForm(form) {
    if (!form || form.dataset.ryanTrackingPrepared === '1') return;
    form.dataset.ryanTrackingPrepared = '1';

    if (!form.querySelector('[name="website"]')) {
      var honeypot = document.createElement('div');
      honeypot.className = 'ryan-lp-honeypot';
      honeypot.setAttribute('aria-hidden', 'true');
      honeypot.innerHTML = '<label>اترك هذا الحقل فارغاً <input type="text" name="website" tabindex="-1" autocomplete="off"></label>';
      insertBeforeSubmit(form, honeypot);
    }

    var consent = document.createElement('div');
    consent.className = 'ryan-lp-consent';
    var label = document.createElement('label');
    var checkbox = document.createElement('input');
    checkbox.type = 'checkbox';
    checkbox.name = 'privacy_consent';
    checkbox.value = '1';
    checkbox.required = true;
    checkbox.setAttribute('aria-describedby', 'ryan-lp-privacy-note');
    var copy = document.createElement('span');
    copy.textContent = 'أوافق على حفظ بيانات الطلب في نظام المتابعة والتواصل معي بشأن الخدمة المطلوبة.';
    label.appendChild(checkbox);
    label.appendChild(copy);
    consent.appendChild(label);
    var note = document.createElement('p');
    note.id = 'ryan-lp-privacy-note';
    note.className = 'ryan-lp-privacy-note';
    note.appendChild(document.createTextNode('لا ترسل مستندات أو معلومات حساسة. تسجيل الطلب لا يعني إرسال رسالة WhatsApp. '));
    if (config.privacyUrl) {
      var privacy = document.createElement('a');
      privacy.href = config.privacyUrl;
      privacy.target = '_blank';
      privacy.rel = 'noopener noreferrer';
      privacy.textContent = 'سياسة الخصوصية';
      note.appendChild(privacy);
    }
    consent.appendChild(note);
    insertBeforeSubmit(form, consent);
  }

  function observeForms() {
    function scan(node) {
      if (!node || node.nodeType !== 1) return;
      if (node.matches('form')) prepareForm(node);
      var forms = node.querySelectorAll ? node.querySelectorAll('form') : [];
      for (var i = 0; i < forms.length; i++) prepareForm(forms[i]);
    }
    scan(document.documentElement);
    if (window.MutationObserver) {
      new MutationObserver(function (mutations) {
        mutations.forEach(function (mutation) {
          for (var i = 0; i < mutation.addedNodes.length; i++) scan(mutation.addedNodes[i]);
        });
      }).observe(document.documentElement, { childList: true, subtree: true });
    }
  }
  observeForms();

  function showFormMessage(form, text, isError) {
    var box = form.querySelector('.ryan-lp-form-error');
    if (!box) {
      box = document.createElement('p');
      box.className = 'ryan-lp-form-error';
      box.setAttribute('role', 'alert');
      box.setAttribute('aria-live', 'polite');
      var submit = form.querySelector('button[type="submit"], input[type="submit"]');
      if (submit && submit.parentNode) submit.parentNode.insertBefore(box, submit);
      else form.appendChild(box);
    }
    box.textContent = text;
    box.dataset.error = isError ? '1' : '0';
    box.hidden = false;
  }

  function successPanel(form, lead, phone, service, details) {
    form.hidden = true;
    var panel = document.createElement('div');
    panel.className = 'ryan-lp-form-success';
    panel.setAttribute('role', 'status');
    panel.setAttribute('aria-live', 'polite');
    var title = document.createElement('strong');
    title.textContent = 'تم حفظ طلبك في نظام المتابعة';
    var note = document.createElement('p');
    note.textContent = 'لإرسال الرسالة إلى فريق ريان، تابع إلى WhatsApp بالضغط على الزر أدناه. فتح WhatsApp وحده لا يؤكد إرسال الرسالة.';
    var link = document.createElement('a');
    var message = 'طلب خدمة من صفحة ' + (config.service || '') + '\nالاسم: ' + lead + '\nالجوال: ' + phone + '\nنوع الخدمة المطلوبة: ' + service + (details ? '\nتفاصيل الطلب: ' + details : '');
    link.href = 'https://wa.me/' + String(config.whatsappNumber || '966503130302').replace(/\D/g, '') + '?text=' + encodeURIComponent(message);
    link.target = '_blank';
    link.rel = 'noopener noreferrer';
    link.className = 'ryan-lp-whatsapp-followup';
    link.textContent = 'متابعة إلى WhatsApp';
    panel.appendChild(title);
    panel.appendChild(note);
    panel.appendChild(link);
    form.insertAdjacentElement('afterend', panel);
    pushAnalyticsEvent('landing_form_submit', 'contact_section', 'website_to_whatsapp');
  }

  document.addEventListener('submit', function (event) {
    var form = event.target;
    if (!(form instanceof HTMLFormElement)) return;
    if (!form.querySelector('input[type="tel"]') && !form.querySelector('input[name*="phone" i]')) return;
    prepareForm(form);
    var contact = findContactFields(form);
    var name = contact.name ? String(contact.name.value || '').trim() : '';
    var phone = contact.phone ? String(contact.phone.value || '').trim() : '';
    var email = contact.email ? String(contact.email.value || '').trim() : '';
    var consent = form.querySelector('input[name="privacy_consent"]');
    if (!name || !phone || !consent || !consent.checked) {
      event.preventDefault();
      event.stopPropagation();
      if (consent && !consent.checked) consent.reportValidity();
      showFormMessage(form, 'أدخل الاسم ورقم الجوال ووافق على استخدام بيانات الطلب للمتابعة.', true);
      return;
    }

    event.preventDefault();
    event.stopPropagation();
    event.stopImmediatePropagation();
    var submit = form.querySelector('button[type="submit"], input[type="submit"]');
    var originalText = submit && submit.textContent;
    if (submit) {
      submit.disabled = true;
      submit.setAttribute('aria-busy', 'true');
    }
    var selectors = form.querySelector('select');
    var details = inputValue(form, 'textarea');
    var submissionEventId = form.dataset.ryanSubmissionEventId || makeUuid();
    form.dataset.ryanSubmissionEventId = submissionEventId;
    var payload = Object.assign({
      event_id: submissionEventId,
      session_id: sessionId,
      page_slug: config.pageSlug,
      name: name,
      phone: phone,
      email: email,
      subservice: selectors ? String(selectors.value || '').trim() : '',
      details: details,
      privacy_consent: true,
      website: inputValue(form, 'input[name="website"]'),
    }, attribution);
    if (config.preview) {
      window.setTimeout(function () {
        successPanel(form, name, phone, payload.subservice || config.service || '', details);
      }, 180);
      return;
    }
    fetch(config.leadEndpoint, {
      method: 'POST',
      credentials: 'same-origin',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload),
    }).then(function (response) {
      return response.json().catch(function () { return {}; }).then(function (body) {
        if (!response.ok || !body.success) throw new Error(body.message || 'request_failed');
        successPanel(form, name, phone, payload.subservice || config.service || '', details);
      });
    }).catch(function () {
      if (submit) {
        submit.disabled = false;
        submit.removeAttribute('aria-busy');
        if (originalText) submit.textContent = originalText;
      }
      showFormMessage(form, 'تعذر حفظ الطلب الآن. لم يتم فتح WhatsApp؛ تحقق من الاتصال ثم أعد المحاولة.', true);
    });
  }, true);
})();
