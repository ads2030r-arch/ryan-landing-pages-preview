# Ryan Engineering Landing Pages 1.3.0

إصدار تنفيذ/اختبار يحافظ على Bundle React الأصلي المرفق، **شعار Header الصحيح** من `sukuk-updated/logo.png`، وبطاقات الخدمات وصورها وأقسام الصفحة كما هي. لا يوجد redesign ولا تعديل للمحتوى/الأقسام باستثناء إقرار موافقة النموذج وحالتي نجاح/فشل الحفظ.

## الصفحات التي تستهدفها الوظائف

- `/lp/surveying-riyadh/`
- `/lp/engineering-consulting-riyadh/`
- `/lp/building-permits-riyadh/`
- `/lp/sukuk/`

## التغييرات الوظيفية

- قاموس موحّد للأحداث: `phone_click`, `whatsapp_click`, `landing_form_submit`. يسجَّل `qualified_lead` داخل CRM فقط عند تغيير المبيعات مرحلة العميل؛ لا يُرسل إلى Google Ads في هذا الإصدار.
- يرسل نموذج الخدمة بيانات الطلب إلى Ryan Sales CRM 0.3.0 أولاً. لا تظهر حالة النجاح ولا يُفتح رابط WhatsApp عند فشل الحفظ.
- زر WhatsApp خطوة منفصلة بعد حفظ CRM، ولا تُعتبر النقرة مكالمة متصلة أو رسالة مرسلة.
- يحفظ CRM source/UTM ومعرفات `gclid`/`gbraid`/`wbraid` حيث تتوفر، في سجل CRM فقط. يمنع إرسال بيانات شخصية أو click IDs/query string إلى dataLayer/GA4.
- عند وجود GTM يُستخدم كناقل وحيد؛ GA4 المباشر بديل فقط عند غياب GTM، منعاً للتكرار.
- يضيف CSS محدوداً للموافقة والتأكيد والخطأ؛ لا يغير الصور أو التخطيط الأصلي للبطاقات.

## البناء والأدلة

- `TRACKING-EVENT-CONTRACT-AR.md`: مواصفة أسماء الأحداث وتدفق CRM/GA4/Google Ads وخطة QA.
- `content/prerender/`: HTML الخادمي للصفحات الأربع، مطابق لمحتوى React الأصلي.
- `scripts/package-release.sh`: يبني ZIP إضافة WordPress، معاينة GitHub Pages وملفات SHA-256.
- `scripts/build-preview.py`: ينشئ معاينة `noindex`، ويعطل الشبكة/التتبع/روابط الاتصال؛ تجربة النموذج محاكاة محلية فقط.

## اعتماد CRM والنطاق

يتطلب النموذج وREST API **Ryan Sales CRM 0.3.0** (`/wp-json/ryan-sales-crm/v1/landing-lead` و`landing-event`). لا يُتوقع عمل حفظ CRM إذا كانت نسخة CRM 0.2.0 فقط؛ في هذه الحالة يفشل الحفظ بأمان ولا يُفتح WhatsApp. الترقية الإنتاجية تحتاج الاختبار المتزامن للنسختين في نافذة تغيير واحدة.

**الحالة:** إصدار تطوير محلي، غير مثبت على WordPress الإنتاجي. لا يغير GTM/GA4/Google Ads ولا أهداف المزايدة أو الصفحة الرئيسية أو المسارات الأخرى. المعاينة العامة (عند بنائها) لا ترسل البيانات لأي خدمة، وهي `noindex`. راجع متطلبات الخصوصية قبل استعمال بيانات حقيقية.
