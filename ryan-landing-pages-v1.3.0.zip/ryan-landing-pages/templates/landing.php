<?php
if (!defined('ABSPATH')) {
    exit;
}

$page = ryan_lp_page_data();
if (!$page) {
    status_header(404);
    nocache_headers();
    ?><!doctype html><html lang="ar" dir="rtl"><meta charset="utf-8"><title>الصفحة غير موجودة</title><body><main><h1>الصفحة غير موجودة</h1><p>تعذر تحميل صفحة الخدمة. يرجى مراجعة إعدادات إضافة Ryan Landing Pages.</p></main></body></html><?php
    exit;
}

$slug = (string) ($page['slug'] ?? '');
$title = (string) ($page['seo_title'] ?? $page['service'] ?? 'مكتب ريان');
$description = (string) ($page['meta_description'] ?? $page['intro'] ?? 'خدمات هندسية ومساحية في الرياض من مكتب ريان.');
$canonical = get_permalink(get_queried_object_id());
$hero_by_slug = array(
    'surveying-riyadh' => 'hero-surveying-desktop.webp',
    'engineering-consulting-riyadh' => 'hero-consulting-desktop.webp',
    'building-permits-riyadh' => 'hero-permits-desktop.webp',
    'sukuk' => 'hero-sukuk-desktop.webp',
);
$hero_image = ryan_lp_asset($hero_by_slug[$slug] ?? 'hero-surveying-desktop.webp');
$logo_image = trailingslashit(RYAN_LP_URL) . 'sukuk-updated/logo.png';
$prerender_file = dirname(__DIR__) . '/content/prerender/' . sanitize_file_name($slug) . '.html';
$prerender_html = is_readable($prerender_file) ? (string) file_get_contents($prerender_file) : '';
if ($prerender_html !== '') {
    $prerender_html = str_replace('__RYAN_ASSET_BASE__', trailingslashit(RYAN_LP_URL), $prerender_html);
} else {
    $prerender_html = '<main dir="rtl"><h1>' . esc_html($page['headline'] ?? $title) . '</h1><p>' . esc_html($page['intro'] ?? $description) . '</p></main>';
}
$css_url = ryan_lp_asset('index-*.css');
$js_url = ryan_lp_asset('index-*.js');
$tracking_css_url = ryan_lp_asset('landing-tracking.css');
$tracking_js_url = ryan_lp_asset('landing-tracking.js');
if ($css_url === '' || $js_url === '') {
    status_header(500);
    ?><!doctype html><html lang="ar" dir="rtl"><meta charset="utf-8"><title>تعذر تحميل الصفحة</title><body><main><h1>تعذر تحميل واجهة الصفحة</h1><p>تأكد من وجود ملفات التصميم الأصلية داخل مجلد assets في الإضافة.</p></main></body></html><?php
    exit;
}
$schema = array(
    '@context' => 'https://schema.org',
    '@type' => 'Service',
    'name' => (string) ($page['service'] ?? $title),
    'description' => $description,
    'provider' => array('@type' => 'Organization', 'name' => 'مكتب ريان للمساحة والاستشارات الهندسية', 'url' => home_url('/')),
    'areaServed' => array('@type' => 'City', 'name' => 'الرياض'),
    'url' => $canonical,
);
?><!doctype html>
<html lang="ar" dir="rtl">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <meta name="robots" content="index,follow,max-image-preview:large">
  <title><?php echo esc_html($title); ?></title>
  <meta name="description" content="<?php echo esc_attr($description); ?>">
  <link rel="canonical" href="<?php echo esc_url($canonical); ?>">
  <meta property="og:type" content="website">
  <meta property="og:locale" content="ar_SA">
  <meta property="og:site_name" content="مكتب ريان للمساحة والاستشارات الهندسية">
  <meta property="og:title" content="<?php echo esc_attr($title); ?>">
  <meta property="og:description" content="<?php echo esc_attr($description); ?>">
  <meta property="og:url" content="<?php echo esc_url($canonical); ?>">
  <?php if ($hero_image !== '') : ?><meta property="og:image" content="<?php echo esc_url($hero_image); ?>"><link rel="preload" as="image" href="<?php echo esc_url($hero_image); ?>" fetchpriority="high"><?php endif; ?>
  <?php if ($logo_image !== '') : ?><link rel="icon" type="image/png" href="<?php echo esc_url($logo_image); ?>"><?php endif; ?>
  <meta name="twitter:card" content="summary_large_image">
  <meta name="twitter:title" content="<?php echo esc_attr($title); ?>">
  <meta name="twitter:description" content="<?php echo esc_attr($description); ?>">
  <?php if ($hero_image !== '') : ?><meta property="twitter:image" content="<?php echo esc_url($hero_image); ?>"><?php endif; ?>
  <script type="application/ld+json"><?php echo wp_json_encode($schema, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES); ?></script>
  <?php ryan_lp_tracking(); ?>
  <link rel="stylesheet" href="<?php echo esc_url($css_url); ?>?ver=<?php echo esc_attr(RYAN_LP_VERSION); ?>">
  <?php if ($tracking_css_url !== '') : ?><link rel="stylesheet" href="<?php echo esc_url($tracking_css_url); ?>?ver=<?php echo esc_attr(RYAN_LP_VERSION); ?>"><?php endif; ?>
  <script>window.RYAN_ASSET_BASE=<?php echo wp_json_encode(trailingslashit(RYAN_LP_URL)); ?>;window.RYAN_ROUTER_BASE="";</script>
</head>
<body class="ryan-landing-page-template">
  <div id="root"><?php echo $prerender_html; ?></div>
  <noscript><p dir="rtl">المحتوى ظاهر؛ بعض عناصر التفاعل تتطلب تشغيل JavaScript.</p></noscript>
  <?php if ($tracking_js_url !== '') : ?><script src="<?php echo esc_url($tracking_js_url); ?>?ver=<?php echo esc_attr(RYAN_LP_VERSION); ?>"></script><?php endif; ?>
  <script type="module" src="<?php echo esc_url($js_url); ?>?ver=<?php echo esc_attr(RYAN_LP_VERSION); ?>"></script>
</body>
</html>
