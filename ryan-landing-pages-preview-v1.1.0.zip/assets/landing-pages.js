(function () {
  "use strict";

  var body = document.body;
  var preview = body && body.dataset.preview === "1";
  var toast = document.querySelector(".rlp-toast");
  var toastTimer;

  function showStatus(message, isError) {
    var status = document.querySelector(".rlp-form-status");
    if (status) {
      status.textContent = message;
      status.classList.toggle("rlp-form-status--error", Boolean(isError));
    }
  }

  function showToast(message) {
    if (!toast) return;
    toast.textContent = message;
    toast.classList.add("is-visible");
    window.clearTimeout(toastTimer);
    toastTimer = window.setTimeout(function () {
      toast.classList.remove("is-visible");
    }, 3200);
  }

  function pushEvent(name, location, service) {
    window.dataLayer = window.dataLayer || [];
    window.dataLayer.push({
      event: name,
      page_path: window.location.pathname,
      page_slug: body.dataset.page || "",
      service: service || body.dataset.service || "",
      cta_location: location || "unknown",
    });
  }

  function handleFormRequest(form, event) {
    if (event) event.preventDefault();
    showStatus("", false);

    if (preview) {
      showStatus(
        "هذه معاينة تصميم فقط؛ لم تُرسل البيانات ولم تُفتح WhatsApp.",
        false,
      );
      return;
    }

    if (!form.checkValidity()) {
      form.reportValidity();
      return;
    }

    var values = new FormData(form);
    var name = String(values.get("name") || "").trim();
    var phone = String(values.get("phone") || "").trim();
    var selectedService = String(values.get("service") || "").trim();
    var location = String(values.get("location") || "").trim();
    var details = String(values.get("details") || "").trim();

    if (!name || !phone || !selectedService) {
      showStatus("يرجى استكمال الاسم ورقم الجوال والخدمة المطلوبة.", true);
      return;
    }

    var parts = [
      "استفسار عن خدمة " + (body.dataset.service || ""),
      "الاسم: " + name,
      "الجوال: " + phone,
      "الخدمة المطلوبة: " + selectedService,
    ];
    if (location) parts.push("الموقع: " + location);
    if (details) parts.push("تفاصيل الطلب: " + details);
    parts.push("مصدر الطلب: صفحة " + (body.dataset.page || ""));

    var message = parts.join("\n");
    var whatsappNumber = "966503130302";
    var url =
      "https://wa.me/" +
      whatsappNumber +
      "?text=" +
      encodeURIComponent(message);

    // This means the visitor requested a WhatsApp hand-off, not that a message was sent or a lead qualified.
    // Never include form values or other personal data in analytics events.
    pushEvent("form_validated_whatsapp_handoff", "lead_form", selectedService);
    window.open(url, "_blank", "noopener,noreferrer");
    showStatus(
      "فُتحت رسالة جاهزة للمراجعة. لم يُرسل الطلب بعد؛ اضغط «إرسال» داخل WhatsApp لإكماله.",
      false,
    );
  }

  if (preview) {
    document.addEventListener("click", function (event) {
      var link = event.target.closest("[data-preview-action]");
      if (!link) return;
      event.preventDefault();
      var action =
        link.dataset.previewAction === "phone" ? "الاتصال" : "WhatsApp";
      showToast("معاينة فقط: زر " + action + " غير مفعّل هنا.");
    });
  } else {
    document.addEventListener("click", function (event) {
      var target = event.target.closest("[data-ryan-event]");
      if (!target) return;
      pushEvent(
        target.dataset.ryanEvent,
        target.dataset.ctaLocation,
        body.dataset.service,
      );
    });
  }

  document.querySelectorAll("[data-ryan-form]").forEach(function (form) {
    // The form intentionally has no submit-type button or URL-based submission fallback.
    // If JavaScript is unavailable, typed data is not transmitted to the page URL.
    form.addEventListener("submit", function (event) {
      event.preventDefault();
    });
    var button = form.querySelector("[data-ryan-submit]");
    if (button) {
      button.addEventListener("click", function (event) {
        handleFormRequest(form, event);
      });
    }
    form.addEventListener("keydown", function (event) {
      if (event.key === "Enter" && event.target.matches("input")) {
        handleFormRequest(form, event);
      }
    });
  });
})();
