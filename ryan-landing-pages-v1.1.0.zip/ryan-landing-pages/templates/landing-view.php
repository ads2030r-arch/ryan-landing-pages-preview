<?php
/**
 * Shared server-rendered landing page view.
 * Expected variables are supplied by the WordPress template or preview builder.
 */
$e = static function ($value) {
    return htmlspecialchars((string) $value, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
};
$asset = static function ($filename) use ($asset_base, $e) {
    return rtrim((string) $asset_base, '/') . '/' . rawurlencode(basename((string) $filename));
};
$brand_name = $brand_name ?? 'مكتب ريان للمساحة والاستشارات الهندسية';
$brand_short = $brand_short ?? 'مكتب ريان';
$phone = $phone ?? '+966503130302';
$phone_display = $phone_display ?? '+966 50 313 0302';
$whatsapp = $whatsapp ?? '966503130302';
$city = $city ?? 'الرياض';
$home_url = $home_url ?? 'https://ryan-sa.com/';
$canonical = $canonical ?? '';
$page_url = $page_url ?? $canonical;
$robots_content = $robots_content ?? ($preview_mode ? 'noindex,nofollow,noarchive' : 'index,follow');
$assets_url = $assets_url ?? $asset_base;
$wa_intro = 'السلام عليكم، أرغب في الاستفسار عن خدمة ' . $page['service'] . ' في ' . $city . '.';
$wa_url = 'https://wa.me/' . preg_replace('/[^0-9]/', '', $whatsapp) . '?text=' . rawurlencode($wa_intro);
$phone_href = 'tel:' . preg_replace('/[^0-9+]/', '', $phone);
$logo_url = $asset('logo-512.webp');
$hero_url = $asset($page['image']);
$mobile_hero_url = $asset($page['mobile_image'] ?? $page['image']);
$schema = array(
    '@context' => 'https://schema.org',
    '@type' => 'Service',
    'name' => $page['service'],
    'description' => $page['meta_description'],
    'provider' => array('@type' => 'Organization', 'name' => $brand_name, 'url' => $home_url),
    'areaServed' => array('@type' => 'City', 'name' => $city),
);
if (!$preview_mode && $canonical !== '') {
    $schema['url'] = $canonical;
}
$schema_json = json_encode($schema, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_HEX_TAG | JSON_HEX_APOS | JSON_HEX_AMP | JSON_HEX_QUOT);
?>
<!doctype html>
<html lang="ar" dir="rtl">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
  <meta name="color-scheme" content="light">
  <meta name="theme-color" content="#3b1720">
  <meta name="robots" content="<?= $e($robots_content) ?>">
  <title><?= $e($page['seo_title']) ?></title>
  <meta name="description" content="<?= $e($page['meta_description']) ?>">
  <?php if (!$preview_mode && $canonical !== ''): ?><link rel="canonical" href="<?= $e($canonical) ?>">
  <?php endif; ?>
  <meta property="og:locale" content="ar_SA">
  <meta property="og:type" content="website">
  <meta property="og:site_name" content="<?= $e($brand_name) ?>">
  <meta property="og:title" content="<?= $e($page['seo_title']) ?>">
  <meta property="og:description" content="<?= $e($page['meta_description']) ?>">
  <?php if ($page_url !== ''): ?><meta property="og:url" content="<?= $e($page_url) ?>"><?php endif; ?>
  <meta property="og:image" content="<?= $e(rtrim($assets_url, '/') . '/' . rawurlencode(basename($page['image']))) ?>">
  <meta property="og:image:alt" content="<?= $e($page['image_alt']) ?>">
  <meta name="twitter:card" content="summary_large_image">
  <meta name="twitter:title" content="<?= $e($page['seo_title']) ?>">
  <meta name="twitter:description" content="<?= $e($page['meta_description']) ?>">
  <meta name="twitter:image" content="<?= $e(rtrim($assets_url, '/') . '/' . rawurlencode(basename($page['image']))) ?>">
  <link rel="icon" href="<?= $e($logo_url) ?>" type="image/webp">
  <link rel="preload" as="image" href="<?= $e($hero_url) ?>" fetchpriority="high">
  <link rel="stylesheet" href="<?= $e($asset('landing-pages.css')) ?>?v=1.1.0">
  <?php if (!$preview_mode && function_exists('ryan_lp_tracking')) { ryan_lp_tracking(); } ?>
  <script type="application/ld+json"><?= $schema_json ?></script>
</head>
<body class="ryan-lp" data-preview="<?= $preview_mode ? '1' : '0' ?>" data-page="<?= $e($page['slug']) ?>" data-service="<?= $e($page['service']) ?>">
  <?php if (!$preview_mode && !empty($gtm_id)): ?>
    <noscript><iframe src="https://www.googletagmanager.com/ns.html?id=<?= $e($gtm_id) ?>" height="0" width="0" style="display:none;visibility:hidden" title="Google Tag Manager"></iframe></noscript>
  <?php endif; ?>
  <?php if ($preview_mode): ?><div class="rlp-preview-banner" role="status">معاينة اختبار فقط — لا تُرسل النماذج ولا تفتح أزرار الاتصال أو WhatsApp.</div><?php endif; ?>
  <a class="rlp-skip" href="#main">انتقل إلى المحتوى</a>
  <header class="rlp-header">
    <a class="rlp-brand" href="<?= $e($home_url) ?>" aria-label="<?= $e($brand_name) ?>">
      <img src="<?= $e($logo_url) ?>" width="52" height="52" alt="" fetchpriority="high">
      <span><strong><?= $e($brand_short) ?></strong><small>للمساحة والاستشارات الهندسية</small></span>
    </a>
    <nav class="rlp-nav" aria-label="التنقل في الصفحة">
      <a href="#services">الخدمات</a>
      <a href="#steps">آلية العمل</a>
      <a href="#faq">الأسئلة الشائعة</a>
    </nav>
    <div class="rlp-header-actions">
      <a class="rlp-phone-link" href="<?= $preview_mode ? '#contact' : $e($phone_href) ?>" <?= $preview_mode ? 'data-preview-action="phone"' : 'data-ryan-event="phone_click" data-cta-location="header"' ?>>اتصل بالمكتب</a>
      <a class="rlp-button rlp-button--small rlp-button--gold" href="<?= $preview_mode ? '#contact' : $e($wa_url) ?>" <?= $preview_mode ? 'data-preview-action="whatsapp"' : 'target="_blank" rel="noopener noreferrer" data-ryan-event="whatsapp_click" data-cta-location="header"' ?>>تواصل عبر WhatsApp</a>
    </div>
  </header>

  <main id="main">
    <div class="rlp-breadcrumb container" aria-label="مسار الصفحة"><a href="<?= $e($home_url) ?>">الرئيسية</a><span aria-hidden="true">/</span><span><?= $e($page['service']) ?></span></div>
    <section class="rlp-hero container" aria-labelledby="page-title">
      <div class="rlp-hero-copy">
        <p class="rlp-eyebrow"><span aria-hidden="true"></span><?= $e($page['eyebrow']) ?></p>
        <h1 id="page-title"><?= $e($page['headline']) ?></h1>
        <p class="rlp-lead"><?= $e($page['intro']) ?></p>
        <ul class="rlp-proof-list" aria-label="مبادئ تقديم الخدمة">
          <li><span aria-hidden="true">✓</span> نطاق عمل واضح قبل البدء</li>
          <li><span aria-hidden="true">✓</span> مراجعة البيانات المتاحة</li>
          <li><span aria-hidden="true">✓</span> توضيح المخرج والخطوة التالية</li>
        </ul>
        <div class="rlp-hero-actions">
          <a class="rlp-button rlp-button--gold" href="<?= $preview_mode ? '#contact' : $e($wa_url) ?>" <?= $preview_mode ? 'data-preview-action="whatsapp"' : 'target="_blank" rel="noopener noreferrer" data-ryan-event="whatsapp_click" data-cta-location="hero"' ?>>ناقش احتياجك عبر WhatsApp <span aria-hidden="true">←</span></a>
          <a class="rlp-button rlp-button--outline" href="#contact">اطلب مراجعة احتياجك</a>
        </div>
        <p class="rlp-hero-note">تُحدد الخدمة والمدة والتكلفة بعد مراجعة تفاصيل الموقع ونطاق الطلب.</p>
      </div>
      <figure class="rlp-hero-media">
        <picture>
          <?php if ($mobile_hero_url !== $hero_url): ?><source media="(max-width: 700px)" srcset="<?= $e($mobile_hero_url) ?>">
          <?php endif; ?>
          <img src="<?= $e($hero_url) ?>" alt="<?= $e($page['image_alt']) ?>" width="1200" height="800" fetchpriority="high" decoding="async">
        </picture>
        <figcaption><span class="rlp-media-mark" aria-hidden="true">R</span><span><strong><?= $e($page['service']) ?></strong><small>مكتب ريان · <?= $e($city) ?></small></span></figcaption>
      </figure>
    </section>

    <section class="rlp-section rlp-services" id="services" aria-labelledby="services-title">
      <div class="container">
        <div class="rlp-section-head"><p class="rlp-eyebrow">ما الذي يمكننا مراجعته؟</p><h2 id="services-title">خدمات <?= $e($page['service']) ?></h2><p>اختر الخدمة الأقرب إلى احتياجك؛ ويُعتمد النطاق النهائي بعد مراجعة بيانات المشروع.</p></div>
        <div class="rlp-service-grid">
          <?php foreach ($page['services'] as $index => $service): ?>
            <article class="rlp-service-card"><span class="rlp-index"><?= sprintf('%02d', $index + 1) ?></span><h3><?= $e($service['title']) ?></h3><p><?= $e($service['text']) ?></p><a href="#contact" aria-label="استفسر عن <?= $e($service['title']) ?>">استفسر عن الخدمة <span aria-hidden="true">←</span></a></article>
          <?php endforeach; ?>
        </div>
      </div>
    </section>

    <section class="rlp-section rlp-steps" id="steps" aria-labelledby="steps-title">
      <div class="container rlp-two-col">
        <div class="rlp-section-head rlp-section-head--left"><p class="rlp-eyebrow">خطوات عملية واضحة</p><h2 id="steps-title">كيف تبدأ؟</h2><p>نبدأ بالمعلومات الأساسية، ثم نوضح لك ما يدخل ضمن الخدمة وما يحتاج إلى مراجعة إضافية.</p><a class="rlp-text-link" href="#contact">أرسل تفاصيل احتياجك <span aria-hidden="true">←</span></a></div>
        <ol class="rlp-step-list">
          <?php foreach ($page['steps'] as $index => $step): ?><li><span><?= sprintf('%02d', $index + 1) ?></span><div><h3><?= $e($step) ?></h3><p><?= $index === 0 ? 'شاركنا المعلومات المتاحة دون الحاجة إلى تجهيز ملف كامل في البداية.' : ($index === 1 ? 'نراجع نطاق الخدمة وما إذا كانت هناك بيانات أو مستندات إضافية.' : 'يتم توضيح المخرج ومسؤوليات كل طرف قبل بدء التنفيذ.') ?></p></div></li><?php endforeach; ?>
        </ol>
      </div>
    </section>

    <section class="rlp-section rlp-prepare" aria-labelledby="prepare-title">
      <div class="container rlp-prepare-panel">
        <div><p class="rlp-eyebrow">لتسريع المراجعة الأولية</p><h2 id="prepare-title">ما الذي يفيد إرساله؟</h2><p>أرسل المتوفر لديك فقط؛ لا تشارك بيانات حساسة غير لازمة للاستفسار الأولي.</p></div>
        <ul><?php foreach ($page['prepare'] as $item): ?><li><span aria-hidden="true">✓</span><?= $e($item) ?></li><?php endforeach; ?></ul>
      </div>
    </section>

    <section class="rlp-section rlp-faq" id="faq" aria-labelledby="faq-title">
      <div class="container rlp-faq-wrap">
        <div class="rlp-section-head"><p class="rlp-eyebrow">إجابات مختصرة</p><h2 id="faq-title">أسئلة شائعة حول <?= $e($page['service']) ?></h2></div>
        <div class="rlp-faq-list">
          <?php foreach ($page['faqs'] as $index => $faq): ?><details class="rlp-faq-item" <?= $index === 0 ? 'open' : '' ?>><summary><?= $e($faq['q']) ?><span aria-hidden="true">+</span></summary><div class="rlp-faq-answer"><p><?= $e($faq['a']) ?></p></div></details><?php endforeach; ?>
        </div>
      </div>
    </section>

    <section class="rlp-section rlp-contact" id="contact" aria-labelledby="contact-title">
      <div class="container rlp-contact-grid">
        <div class="rlp-contact-copy"><p class="rlp-eyebrow">خطوتك التالية</p><h2 id="contact-title">أخبرنا بما تحتاج إليه</h2><p>املأ البيانات الأساسية، وسنجهز لك رسالة في WhatsApp لمراجعتها. لن تُرسل الرسالة إلا بعد ضغط زر الإرسال داخل WhatsApp.</p><div class="rlp-contact-options"><a href="<?= $preview_mode ? '#contact' : $e($phone_href) ?>" <?= $preview_mode ? 'data-preview-action="phone"' : 'data-ryan-event="phone_click" data-cta-location="contact"' ?>><span aria-hidden="true">☎</span><span><small>اتصال هاتفي</small><strong dir="ltr"><?= $e($phone_display) ?></strong></span></a><a href="<?= $preview_mode ? '#contact' : $e($wa_url) ?>" <?= $preview_mode ? 'data-preview-action="whatsapp"' : 'target="_blank" rel="noopener noreferrer" data-ryan-event="whatsapp_click" data-cta-location="contact"' ?>><span aria-hidden="true">◉</span><span><small>WhatsApp</small><strong>مراجعة الطلب عبر المحادثة</strong></span></a></div><p class="rlp-scope-note"><?= $e($page['scope_note']) ?></p></div>
        <form class="rlp-form" data-ryan-form="1" data-preview="<?= $preview_mode ? '1' : '0' ?>" novalidate>
          <label>الاسم <span aria-hidden="true">*</span><input name="name" type="text" autocomplete="name" required maxlength="100" placeholder="الاسم الكامل"></label>
          <label>رقم الجوال <span aria-hidden="true">*</span><input name="phone" type="tel" inputmode="tel" autocomplete="tel" dir="ltr" required maxlength="24" placeholder="05xxxxxxxx"></label>
          <label>الخدمة المطلوبة <span aria-hidden="true">*</span><select name="service" required><option value="" selected disabled>اختر الخدمة الأقرب</option><?php foreach ($page['services'] as $service): ?><option value="<?= $e($service['title']) ?>"><?= $e($service['title']) ?></option><?php endforeach; ?></select></label>
          <label>موقع العقار أو المشروع <span class="rlp-optional">اختياري</span><input name="location" type="text" maxlength="180" placeholder="المدينة أو الحي"></label>
          <label>تفاصيل مختصرة <span class="rlp-optional">اختياري</span><textarea name="details" rows="3" maxlength="1200" placeholder="ما الذي ترغب في إنجازه؟"></textarea></label>
          <p class="rlp-privacy-note">تُستخدم البيانات التي تكتبها لإنشاء رسالة WhatsApp على جهازك؛ لا تُرسل إلى أدوات التحليل. راجع الرسالة ثم أرسلها بنفسك.</p>
          <button class="rlp-button rlp-button--whatsapp" type="button" data-ryan-submit>متابعة إلى WhatsApp <span aria-hidden="true">←</span></button>
          <p class="rlp-form-status" aria-live="polite" role="status"></p>
        </form>
      </div>
    </section>
  </main>

  <footer class="rlp-footer"><div class="container rlp-footer-inner"><a class="rlp-brand rlp-brand--footer" href="<?= $e($home_url) ?>"><img src="<?= $e($logo_url) ?>" width="42" height="42" alt=""><span><strong><?= $e($brand_short) ?></strong><small>للمساحة والاستشارات الهندسية</small></span></a><p>خدمات هندسية ومساحية في <?= $e($city) ?> — يُحدد نطاق كل خدمة بعد مراجعة الطلب.</p><a href="<?= $preview_mode ? '#contact' : $e($phone_href) ?>" <?= $preview_mode ? 'data-preview-action="phone"' : 'data-ryan-event="phone_click" data-cta-location="footer"' ?> dir="ltr"><?= $e($phone_display) ?></a></div></footer>

  <nav class="rlp-mobile-bar" aria-label="التواصل السريع"><a href="<?= $preview_mode ? '#contact' : $e($phone_href) ?>" <?= $preview_mode ? 'data-preview-action="phone"' : 'data-ryan-event="phone_click" data-cta-location="mobile_bar"' ?>><span aria-hidden="true">☎</span>اتصال</a><a href="<?= $preview_mode ? '#contact' : $e($wa_url) ?>" <?= $preview_mode ? 'data-preview-action="whatsapp"' : 'target="_blank" rel="noopener noreferrer" data-ryan-event="whatsapp_click" data-cta-location="mobile_bar"' ?>><span aria-hidden="true">◉</span>WhatsApp</a></nav>
  <?php if ($preview_mode): ?><div class="rlp-toast" aria-live="polite" role="status"></div><?php endif; ?>
  <script src="<?= $e($asset('landing-pages.js')) ?>?v=1.1.0" defer></script>
</body>
</html>
