<?php
if (!defined('ABSPATH')) {
    exit;
}

$page = ryan_lp_page_data();
if (!$page) {
    status_header(404);
    nocache_headers();
    ?><!doctype html><html lang="ar" dir="rtl"><meta charset="utf-8"><title>الصفحة غير موجودة</title><body><main><h1>الصفحة غير موجودة</h1><p>تعذر تحميل بيانات صفحة الخدمة. يرجى مراجعة إعدادات إضافة Ryan Landing Pages.</p></main></body></html><?php
    exit;
}

$preview_mode = false;
$brand_name = 'مكتب ريان للمساحة والاستشارات الهندسية';
$brand_short = 'مكتب ريان';
$phone = '+966503130302';
$phone_display = '+966 50 313 0302';
$whatsapp = '966503130302';
$city = 'الرياض';
$home_url = home_url('/');
$canonical = get_permalink(get_queried_object_id());
$page_url = $canonical;
$robots_content = 'index,follow';
$asset_base = trailingslashit(RYAN_LP_URL . 'assets');
$assets_url = $asset_base;
$tracking_ids = ryan_lp_tracking_ids();
$gtm_id = $tracking_ids['gtm'];
require RYAN_LP_DIR . 'templates/landing-view.php';
