<?php
/**
 * Plugin Name: Ryan Engineering Landing Pages
 * Description: صفحات هبوط عربية مستقلة ومهيأة لمحركات البحث لمكتب ريان.
 * Version: 1.1.0
 * Author: Ryan Engineering
 * Text Domain: ryan-landing-pages
 */
if (!defined('ABSPATH')) {
    exit;
}

define('RYAN_LP_VERSION', '1.1.0');
define('RYAN_LP_DIR', plugin_dir_path(__FILE__));
define('RYAN_LP_URL', plugin_dir_url(__FILE__));

function ryan_lp_slugs() {
    return array('surveying-riyadh', 'engineering-consulting-riyadh', 'building-permits-riyadh', 'sukuk');
}

function ryan_lp_is_page() {
    return function_exists('is_page') && is_page(ryan_lp_slugs());
}

function ryan_lp_all_page_data() {
    static $data = null;
    if ($data !== null) {
        return $data;
    }
    $file = RYAN_LP_DIR . 'content/landing-pages.json';
    if (!is_readable($file)) {
        $data = array();
        return $data;
    }
    $decoded = json_decode(file_get_contents($file), true);
    $data = is_array($decoded) && !empty($decoded['pages']) ? $decoded : array();
    return $data;
}

function ryan_lp_current_slug() {
    if (!ryan_lp_is_page()) {
        return '';
    }
    $post_id = function_exists('get_queried_object_id') ? (int) get_queried_object_id() : 0;
    $slug = $post_id && function_exists('get_post_field') ? get_post_field('post_name', $post_id) : '';
    return is_string($slug) ? sanitize_title($slug) : '';
}

function ryan_lp_page_data($slug = '') {
    $slug = $slug !== '' ? $slug : ryan_lp_current_slug();
    if ($slug === '') {
        return null;
    }
    $data = ryan_lp_all_page_data();
    foreach ((array) ($data['pages'] ?? array()) as $page) {
        if (!empty($page['slug']) && hash_equals((string) $page['slug'], (string) $slug)) {
            return $page;
        }
    }
    return null;
}

function ryan_lp_asset($file) {
    $file = basename((string) $file);
    $path = RYAN_LP_DIR . 'assets/' . $file;
    return is_file($path) ? RYAN_LP_URL . 'assets/' . rawurlencode($file) : '';
}

function ryan_lp_tracking_ids() {
    $gtm = strtoupper(trim((string) get_option('ryan_lp_gtm_id', '')));
    $ga4 = strtoupper(trim((string) get_option('ryan_lp_ga4_id', '')));
    if (!preg_match('/^GTM-[A-Z0-9]+$/', $gtm)) {
        $gtm = '';
    }
    if (!preg_match('/^G-[A-Z0-9]+$/', $ga4)) {
        $ga4 = '';
    }
    return array('gtm' => $gtm, 'ga4' => $ga4);
}

function ryan_lp_tracking() {
    if (!ryan_lp_is_page()) {
        return;
    }
    $ids = ryan_lp_tracking_ids();
    if ($ids['gtm'] !== '') {
        $container = wp_json_encode($ids['gtm']);
        echo "<script>window.dataLayer=window.dataLayer||[];window.dataLayer.push({'gtm.start':new Date().getTime(),event:'gtm.js'});</script>\n";
        echo '<script>(function(w,d,s,l,i){w[l]=w[l]||[];var f=d.getElementsByTagName(s)[0],j=d.createElement(s),dl=l!=="dataLayer"?"&l="+l:"";j.async=true;j.src="https://www.googletagmanager.com/gtm.js?id="+i+dl;f.parentNode.insertBefore(j,f);})(window,document,"script","dataLayer",' . $container . ');</script>' . "\n";
    } elseif ($ids['ga4'] !== '') {
        $measurement = esc_attr($ids['ga4']);
        $measurement_json = wp_json_encode($ids['ga4']);
        echo '<script async src="https://www.googletagmanager.com/gtag/js?id=' . $measurement . '"></script>' . "\n";
        echo '<script>window.dataLayer=window.dataLayer||[];function gtag(){dataLayer.push(arguments);}gtag("js",new Date());gtag("config",' . $measurement_json . ');</script>' . "\n";
    }
}

function ryan_lp_template($template) {
    if (ryan_lp_is_page()) {
        return RYAN_LP_DIR . 'templates/landing.php';
    }
    return $template;
}
add_filter('template_include', 'ryan_lp_template', 99);

function ryan_lp_body_class($classes) {
    if (ryan_lp_is_page()) {
        $classes[] = 'ryan-landing-page-template';
    }
    return $classes;
}
add_filter('body_class', 'ryan_lp_body_class');

function ryan_lp_sanitize_gtm_id($value) {
    $value = strtoupper(trim(sanitize_text_field((string) $value)));
    return preg_match('/^GTM-[A-Z0-9]+$/', $value) ? $value : '';
}
function ryan_lp_sanitize_ga4_id($value) {
    $value = strtoupper(trim(sanitize_text_field((string) $value)));
    return preg_match('/^G-[A-Z0-9]+$/', $value) ? $value : '';
}
function ryan_lp_admin_menu() {
    add_options_page('Ryan Landing Pages', 'Ryan Landing Pages', 'manage_options', 'ryan-landing-pages', 'ryan_lp_settings_page');
}
add_action('admin_menu', 'ryan_lp_admin_menu');
function ryan_lp_register_settings() {
    register_setting('ryan_lp_settings', 'ryan_lp_gtm_id', array('sanitize_callback' => 'ryan_lp_sanitize_gtm_id'));
    register_setting('ryan_lp_settings', 'ryan_lp_ga4_id', array('sanitize_callback' => 'ryan_lp_sanitize_ga4_id'));
}
add_action('admin_init', 'ryan_lp_register_settings');
function ryan_lp_settings_page() {
    if (!current_user_can('manage_options')) {
        return;
    }
    ?>
    <div class="wrap" dir="rtl">
      <h1>Ryan Landing Pages</h1>
      <p>تُعرض الصفحات الأربع أدناه بقالب مستقل ومحتوى خادمي. لا تغيّر هذه الإعدادات الصفحة الرئيسية أو صفحات الموقع الأخرى.</p>
      <form method="post" action="options.php">
        <?php settings_fields('ryan_lp_settings'); ?>
        <table class="form-table">
          <tr><th scope="row">معرّف Google Tag Manager</th><td><input class="regular-text" name="ryan_lp_gtm_id" value="<?php echo esc_attr(get_option('ryan_lp_gtm_id', '')); ?>" placeholder="GTM-XXXXXXX" /><p class="description">عند ضبط GTM يُستخدم GTM فقط، ويجب إعداد GA4 والأحداث من داخل الحاوية.</p></td></tr>
          <tr><th scope="row">معرّف GA4 بديل</th><td><input class="regular-text" name="ryan_lp_ga4_id" value="<?php echo esc_attr(get_option('ryan_lp_ga4_id', '')); ?>" placeholder="G-XXXXXXXXXX" /><p class="description">يعمل فقط عند عدم وجود GTM صالح.</p></td></tr>
        </table>
        <?php submit_button('حفظ الإعدادات'); ?>
      </form>
      <h2>المسارات التي تستخدم القالب</h2>
      <ol><li>/lp/surveying-riyadh/</li><li>/lp/engineering-consulting-riyadh/</li><li>/lp/building-permits-riyadh/</li><li>/lp/sukuk/</li></ol>
      <p>أحداث الواجهة لا تتضمن الاسم أو رقم الهاتف أو نص الرسالة. نقر الاتصال أو WhatsApp ليس دليلاً على مكالمة أو رسالة مرسلة أو عميل مؤهل.</p>
    </div>
    <?php
}
